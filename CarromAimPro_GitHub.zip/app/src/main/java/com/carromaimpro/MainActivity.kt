package com.carromaimpro

import android.app.Activity
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.Path

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(AimView())
    }
    class AimView : View(this@MainActivity) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 193, 7); strokeWidth = 7f; style = Paint.Style.STROKE
        }
        private var x0 = 0f
        private var y0 = 0f
        private var x1 = 0f
        private var y1 = 0f
        private var started = false
        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            c.drawColor(Color.rgb(25, 35, 45))
            val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 42f }
            c.drawText("Carrom Aim Pro", 40f, 80f, t)
            t.textSize = 28f
            c.drawText("اسحب إصبعك لرسم خط التصويب التجريبي", 40f, 130f, t)
            if (started) {
                c.drawLine(x0, y0, x1, y1, p)
                val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.RED; style = Paint.Style.FILL }
                c.drawCircle(x0, y0, 13f, dot)
            }
        }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { x0=e.x; y0=e.y; x1=e.x; y1=e.y; started=true; invalidate(); return true }
                MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> { x1=e.x; y1=e.y; invalidate(); return true }
            }
            return true
        }
    }
}
