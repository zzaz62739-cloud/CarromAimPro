package com.carromaimpro

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

/**
 * Prototype only: touch once to set a direction ray.
 * It does NOT yet detect the board or discs from the game screen.
 */
class AimOverlayView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var startX = 0f
    private var startY = 0f
    private var endX = 0f
    private var endY = 0f
    private var hasAim = false

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!hasAim) {
            paint.color = Color.WHITE
            paint.textSize = 38f
            canvas.drawText("نافذة تجريبية: اسحب لتحديد اتجاه الخط", 30f, 90f, paint)
            return
        }
        val dx = endX - startX
        val dy = endY - startY
        val length = hypot(dx, dy).coerceAtLeast(1f)
        val scale = 1800f / length
        val farX = startX + dx * scale
        val farY = startY + dy * scale

        paint.color = Color.YELLOW
        paint.strokeWidth = 5f
        canvas.drawLine(startX, startY, farX, farY, paint)
        paint.color = Color.WHITE
        canvas.drawCircle(startX, startY, 10f, paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                startX = event.x
                startY = event.y
                endX = event.x + 1f
                endY = event.y + 1f
                hasAim = true
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> {
                endX = event.x
                endY = event.y
                invalidate()
                return true
            }
        }
        return true
    }
}
